var BloodThirsty =
{
    healthBoost: 0,

    unit: {},

    Constructor: function(unit, args)
    {
        var that = this;
        this.unit = unit;
        this.healthBoost = args.healthBoost;
        game.observer.Listen(KILLED_UNIT, this, function(speaker, listener, params)
        {
            that.unit.health += healthBoost;
        });
    }
}
BloodThirsty = Class(BloodThirsty);
