AbilityList =
{
    "BloodThirsty": BloodThirsty
}
