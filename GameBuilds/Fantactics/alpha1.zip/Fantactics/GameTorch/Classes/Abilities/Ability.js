var Ability =
{
    unit: {},

    Constructor: function(){},

    Construct: function(ability, unit)
    {
        ability.unit = unit;
    },

    React: function()
    {

    }
}


//events

KILLED_UNIT = "KILLEDUNIT";
