var Efect =
{


}



var BloodEffect =  function(target, callback)
{
    //
    // var BloodSprite = new Torch.Sprite(unitInCell.Rectangle.x, unitInCell.Rectangle.y);
    // game.Add(BloodSprite);
    // BloodSprite.drawIndex = 10;
    // BloodSprite.Bind.TextureSheet("explosion");

    var spurts = 3;
    var delayTime = 600;
    var delayFactor = 1;

    var spurt = function(sprite)
    {
        var BloodSprite = new Torch.Sprite( sprite.Rectangle.x, sprite.Rectangle.y);
        game.Add(BloodSprite);
        BloodSprite.drawIndex = 10;
        BloodSprite.Bind.TextureSheet("explosion");
        BloodSprite.TextureSheetAnimation.Single();
        BloodSprite.Once();
        BloodSprite.TextureSheetAnimation.finishCallBack = callback;

    }

    setTimeout(spurt, delayTime, target);
}
var BlueMagicEffect = function(target, callback)
{
    var spurts = 3;
    var delayTime = 600;
    var delayFactor = 1;

    var spurt = function(sprite)
    {
        var BloodSprite = new Torch.Sprite( sprite.Rectangle.x, sprite.Rectangle.y);
        game.Add(BloodSprite);
        BloodSprite.drawIndex = 10;
        BloodSprite.Bind.TextureSheet("blue_magic");
        BloodSprite.TextureSheetAnimation.Single();
        BloodSprite.Once();
        BloodSprite.TextureSheetAnimation.finishCallBack = callback;

    }

    setTimeout(spurt, delayTime, target);
}
