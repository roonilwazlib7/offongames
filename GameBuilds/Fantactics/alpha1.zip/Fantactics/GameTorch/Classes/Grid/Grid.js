
var TerrainType = {};
TerrainType.Plain = "PLAIN";
TerrainType.Forest = "FOREST";
TerrainType.Mountain = "MOUNTAIN";

var Grid =
{
		cellSize: 0,
		dimension: 0,
		game:{},
		cellTexture:null,
		activeCellTexture:null,
		Cells: [],
		CellMap: [],

		Constructor: function(dimension, game)
		{
			this.cellSize = 64;
			this.dimension = dimension;
			this.game = game;
		},

		GetCell: function(row, column)
		{
			var that = this;
			return that.Cells[that.CellMap[row.toString() + ":" + column.toString()]];
		},

		Slide: function(amount)
		{
			var that = this;
			that.Cells.forEach(function(cell)
			{
				cell.Rectangle.x += amount;
				if (cell.HasUnit)
				{
					cell.unit.Rectangle.x += amount;
				}
			});
		},

		Init: function()
		{
			var that = this;
			var game = that.game;
			var cellsHorizontal = that.dimension;
			var cellsVertical = that.dimension;

			for (var i = 0; i <= cellsHorizontal; i++)
			{
				for (var j = 0; j <= cellsHorizontal; j++)
				{
					var newCell = new Torch.Sprite(i * that.cellSize, j * that.cellSize);
					//var locText = new Torch.Text("(" + i + "," + j + ")", i * that.cellSize, (j * that.cellSize) + 10, {font: "10px pixel", fillStyle: "black"} );
					//game.Add(locText);
					var rand = Math.random() * 100;
					if (rand <= 80)
					{
						newCell.Terrain = TerrainType.Plain;
						newCell.moveCost = 1;
					}
					if (rand > 80 && rand < 90)
					{
						newCell.Terrain = TerrainType.Forest;
						newCell.moveCost = 1;
					}
					if (rand >= 90)
					{
						newCell.Terrain = TerrainType.Mountain;
						newCell.moveCost = 1;
					}

					newCell.Terrain = TerrainType.Plain;

					newCell.Row = i;
					newCell.Column = j;
					game.Add(newCell);
					newCell.Seen = [];
					newCell.Reveal = function()
					{
						var that = this;
						var terrainToBind = "";
						switch (that.Terrain)
						{
							case TerrainType.Plain:
								terrainToBind = "plain";
							break;

							case TerrainType.Forest:
								terrainToBind = "forest";
							break;

							case TerrainType.Mountain:
								terrainToBind = "mountain";
							break;
						}
						that.Bind.Texture(terrainToBind);
					}
					newCell.Reveal();
					that.Cells.push(newCell);
					that.CellMap[i.toString() + ":" + j.toString()] = that.Cells.length - 1;
				}
			}


	}
};

Grid = Class2(Grid);
