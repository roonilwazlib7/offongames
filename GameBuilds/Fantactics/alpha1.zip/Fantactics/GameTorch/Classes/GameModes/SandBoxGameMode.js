
(function(){

	var SandBoxGameMode = new Class(function(grid) //Maybe make a new player within instead?
	{
		;"SandBoxGameMode";
		this.grid = grid;
		this.info = new Torch.Text("",100,50,{font: "20px Consolas", fillStyle: "red", strokeStyle: "white"});
		game.Add(this.info);
	});



	SandBoxGameMode.Prop("turnCount", 0);
	SandBoxGameMode.Prop("playerInControl", null);
	SandBoxGameMode.Prop("playerNotInControl", null);
	SandBoxGameMode.Prop("ui", null);

	SandBoxGameMode.Prop("lockTime", 0);


	SandBoxGameMode.Prop("CheckIfUnitIsSelected", function()
	{
		var that = this;
		if (that.player1.UnitIsSelected() || that.player2.UnitIsSelected())
		{
			return true;
		}
		else
		{
			return false;
		}
	});


		//control functions
	SandBoxGameMode.Prop("LockAndWait", function()
	{

	});
	SandBoxGameMode.Prop("SwitchControl", function()
	{
		var that = this;
		that.turnCount++;
		that.playerInControl.GiveUpControl();
		that.playerNotInControl.TakeControl(that.playerInControl);




		var newInControlPlayer = that.playerNotInControl;
		var newNotInControlPlayer = that.playerInControl;

		that.playerInControl = newInControlPlayer;
		that.playerNotInControl = newNotInControlPlayer;
	});
	SandBoxGameMode.Prop("CheckControl", function()
	{
		var that = this;
		if (that.playerInControl.TurnIsDone() && that.lockTime >= 1000)
		{
			that.SwitchControl();
			that.lockTime = 0;
		}
		else if (that.playerInControl.TurnIsDone())
		{
			that.lockTime += game.deltaTime;
		}
	});
	SandBoxGameMode.Prop("Control",  function()
	{
		var that = this;
		that.CheckControl();
			//any other items related to the control of the game
	});

	//public non-functions


	//public functions
	SandBoxGameMode.Prop("Init", function()
	{
		var that = this;
		that.grid.Init();


		that.player1 = new GoblinPlayer(that.grid);
		that.player2 = new ElfPlayer(that.grid);


		that.player1.name = "Player1";
		that.player2.name = "Player2";

		that.player1.color = "blue";
		that.player2.color = "red";

		var PlayerTwoUnits =
		[
			new ElvenArcher(that.grid, that.grid.GetCell(4,4), that.player2, that.grid.game)
		];
		var PlayerOneUnits =
		[
			new GoblinBruiser(that.grid, that.grid.GetCell(4,6), that.player1, that.grid.game),
			new GoblinBruiser(that.grid, that.grid.GetCell(6,8), that.player1, that.grid.game)
		];
		that.player2.Units = PlayerTwoUnits;
		that.player1.Units = PlayerOneUnits;

		that.player1.TakeControl();

		that.playerInControl = that.player1;
		that.playerNotInControl = that.player2;
	});

	SandBoxGameMode.Prop("Draw", function()
	{
		var that = this;
	});

	SandBoxGameMode.Prop("Update", function()
	{
		var that = this;
		//that.grid.Update();
		 that.player1.Update();
		 that.info.text = "It is " + that.playerInControl.name + "'s turn";
		 that.player2.Update();
		// that.ui.Update();
		 that.Control();
	});


	window["SandBoxGameMode"] = SandBoxGameMode;

})();
