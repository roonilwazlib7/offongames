var UnitGridSearch = new Class(function()
{
    ;"UnitGridSearch";
});

UnitGridSearch.Prop("AreAllMovesTheSame", function(moveList)
{
    var that = this;
    var firstElem = moveList[0];
    for (var i = 0; i < moveList.length; i++)
    {
        if (moveList[i] != firstElem)
        {
            return false;
        }
    }
    return true;
});

UnitGridSearch.Prop("CheckForComplexPaths", function(failedMovePath)
{
    var that = this;
    var repeatedMove = "";
    var op1 = "";
    var op2 = "";
    if (that.AreAllMovesTheSame(failedMovePath))
    {
        repeatedMove = failedMovePath[0];
        if (repeatedMove == "l" || repeatedMove == "r")
        {
            op1 = "u";
            op2 = "d";
            h = true;
        }
        else
        {
            op1 = "r";
            op2 = "l";
        }
        failedMovePath.pop();

        var complexPattern = failedMovePath.concat([op1,op2,repeatedMove]);
        var altComplexPattern = [op1,repeatedMove].concat(failedMovePath).concat([op2]);

        var perms = that.permutator(complexPattern);
        var altPerms = that.permutator(altComplexPattern);

        perms = perms.concat(altPerms);

        for (var i = 0; i < perms.length; i++)
        {
            if (that.AbsoluteValidatePath(perms[i]) && perms[i].length <= that.movesToGo)
            {
                return true;
            }
        }
        return false;
    }
});

UnitGridSearch.Prop("ValidatePath", function(path)
{
    //Needs to be fixed!!!
    var that = this;
    var dH = 0;
    var dV = 0;
    var distance = 0;
    var movesToGo = that.movesToGo;
    for (var i = 0; i < path.length; i++)
    {
        var checkCell;

        switch (path[i])
        {
            case "l":
                dH--;
            break;
            case "r":
                dH++;
            break;
            case "u":
                dV--;
            break;
            case "d":
                dV++;
            break;

        }
        checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
        distance += checkCell.moveCost;
        if (checkCell.HasUnit && checkCell.unit.player.name != that.player.name)
        {
            return that.CheckForComplexPaths(path);
        }
    }
    if (distance <= movesToGo)
    {
        return true;
    }
    else return false;
});

UnitGridSearch.Prop("AbsoluteValidatePath", function(path)
{
    //Needs to be fixed!!!
    var that = this;
    var dH = 0;
    var dV = 0;
    var distance = 0;
    var movesToGo = that.movesToGo;
    for (var i = 0; i < path.length; i++)
    {
        var checkCell;
        switch (path[i])
        {
            case "l":
                dH--;
            break;
            case "r":
                dH++;
            break;
            case "u":
                dV--;
            break;
            case "d":
                dV++;
            break;

        }
        checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
        if (checkCell) distance += checkCell.moveCost;
        if (checkCell.HasUnit && checkCell.unit.player.name != that.player.name)
        {
            return false;
        }
    }
    if (distance <= movesToGo) return true;
    else return false;
});

UnitGridSearch.Prop("permutator", function(ar) {
    var allArrays = ar;
    var res = [];

    // Pre-calculate divisors
    var divisors = [];
    for (var i = allArrays.length - 1; i >= 0; i--) {
       divisors[i] = divisors[i + 1] ? divisors[i + 1] * allArrays[i + 1].length : 1;
    }

    function getPermutation(n) {
       var result = "", curArray;

       for (var i = 0; i < allArrays.length; i++) {
          curArray = allArrays[i];
          result += curArray[Math.floor(n / divisors[i]) % curArray.length];
       }

       return result;
    }
    for (var i = 0; i < ar.length * ar.length; i++)
    {
        res.push(getPermutation(i).split(""));
    }
    return res;
});

UnitGridSearch.Prop("PruneMoveHints", function(cells, dist)
{
    var that = this;
    prunedCells = [];
    movePaths = [];
    //that.CellToMovePathMap = [];
    for (var i = 0; i < cells.length; i++)
    {
        var cell = cells[i];
        var up = (cell.Column - that.locationCell.Column) <= 0 ? true : false;
        var left = (cell.Row - that.locationCell.Row) <= 0 ? true : false;
        var movesH = Math.abs(cell.Row - that.locationCell.Row);
        var movesV = Math.abs(cell.Column - that.locationCell.Column);
        var movePattern = [];
        var movePattern2 = []
        for (var j = 0; j < movesH; j++)
        {
            if (left)
            {
                movePattern.push("l");
            }
            else
            {
                movePattern.push("r");
            }
        }
        for (var k = 0; k < movesV; k++)
        {
            if (up)
            {
                movePattern.push("u");
            }
            else
            {
                movePattern.push("d");
            }
        }

        for (var k = 0; k < movesV; k++)
        {
            if (up)
            {
                movePattern2.push("u");
            }
            else
            {
                movePattern2.push("d");
            }
        }
        for (var j = 0; j < movesH; j++)
        {
            if (left)
            {
                movePattern2.push("l");
            }
            else
            {
                movePattern2.push("r");
            }
        }

        var alt = that.permutator(movePattern2);
        var allPossiblePermutaionsOfMovePattern = that.permutator(movePattern).concat(alt);
        for (var h = 0; h < allPossiblePermutaionsOfMovePattern.length; h++)
        {
            var pattern = allPossiblePermutaionsOfMovePattern[h];
            if (that.ValidatePath(pattern))
            {
                that.CellToMovePathMap[cell.Row.toString() + "," + cell.Column.toString()] = pattern;
                prunedCells.push(cell);
                break;
            }
        }
    }
    return prunedCells;
});
