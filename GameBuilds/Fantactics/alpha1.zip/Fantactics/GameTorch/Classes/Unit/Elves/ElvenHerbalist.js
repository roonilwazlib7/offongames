(function(){

    var ElvenHerbalist = new Class(function(grid, initialCell, player, game) {
		;"ElvenHerbalist";

        Unit.Construct(this, grid, initialCell, player, game, "elven_herbalist");

        this.PlayerTitle = "ElvenHerbalist";

    });

    ElvenHerbalist.Inherits(Unit);

    ElvenHerbalist.Override("moveRange", 3);
    ElvenHerbalist.Override("power", 10);
    ElvenHerbalist.Override("strength", 10);
    ElvenHerbalist.Override("health", 40);


    window["ElvenHerbalist"] = ElvenHerbalist;



})();
