

var ElvenArcher =
{
    Constructor: function(grid, initialCell, player, game)
    {
        this.texture = "elven_archer";
        this.Init(grid, initialCell, player, game);

        this.PlayerTitle = "ElvenArcher";
    }
}

ElvenArcher = Class(ElvenArcher);
ElvenArcher.Extend(Unit);
ElvenArcher.Extend(Data.Elves.Units.ElvenArcher);
