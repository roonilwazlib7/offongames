(function(){

    var GoblinWarLord = new Class(function(grid, initialCell, player, game) {
		;"GoblinWarLord";

        Unit.Construct(this, grid, initialCell, player, game, "goblin_war_lord");

        this.PlayerTitle = "GoblinWarLord";

    });

    GoblinWarLord.Inherits(Unit);

    GoblinWarLord.Override("moveRange", 3);
    GoblinWarLord.Override("power", 25);
    GoblinWarLord.Override("strength", 0);
    GoblinWarLord.Override("health", 20)


    window["GoblinWarLord"] = GoblinWarLord;



})();
