

var GoblinBruiser =
{
    Constructor: function(grid, initialCell, player, game)
    {
        var that = this;
        this.texture = "goblin_bruiser";
        this.Init(grid, initialCell, player, game);

        this.PlayerTitle = "GoblinBruiser";
        this.AttackEffect = this.DefendEffect = BloodEffect;
        // var shell = new Torch.Sprite(initialCell.Rectangle.x, initialCell.Rectangle.y);
        // game.Add(shell);
        // shell.Bind.Texture("goblin_theif_shell");
        // shell.drawIndex = 7;
        // shell.TieLocation(that, {});
        // this.AttackEffect = this.DefendEffect = BloodEffect_1;
    }
}

GoblinBruiser = Class(GoblinBruiser);
GoblinBruiser.Extend(Unit);
GoblinBruiser.Extend(Data.Goblins.Units.GoblinBruiser);
