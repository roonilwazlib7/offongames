

var GrandWizard =
{
    Constructor: function(grid, initialCell, player, game)
    {
        this.texture = "grand_wizard";
        this.Init(grid, initialCell, player, game);

        this.PlayerTitle = "GrandWizard";
        this.AttackEffect = this.DefendEffect = BlueMagicEffect;
        this.teleportTurnsToGo = 0;
        this.AddUpdate(this.Teleport);
        this.FinishUpFunctions.push(function(sprite)
        {
            if (sprite.teleportTurnsToGo > 0) sprite.teleportTurnsToGo--;
        });
    },

    //Abilities
    Teleport: function(sprite)
    {
        var that = sprite;
        if (game.Keys.T.down && game.Mouse.down && that.selected && that.teleportTurnsToGo == 0)
        {
            for (var i = 0; i < that.grid.Cells.length; i++)
            {
                var cell = that.grid.Cells[i];
                if ( that.game.Mouse.GetRectangle(that.game).Intersects(cell.Rectangle) )
                {
                    that.locationCell.HasUnit = false;
                    that.locationCell.unit = null;
                    that.locationCell = cell;
                    that.locationCell.HasUnit = true;
                    that.locationCell.unit = that;


                    that.Rectangle.x = cell.Rectangle.x;
                    that.Rectangle.y = cell.Rectangle.y;
                    that.selected = false;
                    that.ClearHintCells();
                    that.teleportTurnsToGo = 20;
                }
            }
        }
    }
}

GrandWizard = Class(GrandWizard);
GrandWizard.Extend(Unit);
GrandWizard.Extend(Data.Wizards.Units.GrandWizard);
