var Unit =
{
    moveRange: 0,
    attackRange: 0,
    power: 0,
    strength: 0,
    health: 0,
    vision: 0,
    plainMoveCost: 1,
    forestMoveCost: 2,
    mountainMoveCost: 3,
    movesToGo: 0,
    gold: 0,

    texture: "",

    selected: false,
    movedThisTurn: false,
    attackedThisTurn: false,
    doneThisTurn: false,
    moving: false,
    zTrig: false,

    locationCell: {},

    MoveHintCells: [],
    AttackHintCells: [],
    MovePath: [],
    ItemInventory: [],

    Constructor: function()
    {
        VOID;
        var that = this;
        that.Init();
    },

    Init: function(grid, initialCell, player, game)
    {
        VOID;
        //call this method on all derived units
        var that = this;
        var healthText;
        that.grid = grid;
        that.locationCell = initialCell;
        that.locationCell.HasUnit = true;
        that.locationCell.unit = that;
        that.playerName = player.name;
        that.player = player;
        that.game = game;

        that.InitSprite();
        that.drawIndex = 2;
        that.BindEvents();

        that.grid = grid;
        that.FinishUpFunctions = [];
        that.StartUpFunctions = [];
		that.OwnedAbilities = [];
        that.CellToMovePathMap = [];
        that.CellsInVison = [];
        that.CellsAddedToVison = [];
        that.ItemInventory = [];
		that.PlayerIsInControl = false;

		that.movesToGo = that.moveRange;

		that.DrawParams = {alpha:1,rotation:0};

        that.Rectangle = new Torch.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, 0, 0);
		game.Add(that);
		that.Bind.Texture(that.texture);
        that.AddUpdate(that._Update);

		that.vision = that.vision + that.moveRange + that.attackRange;//??

        that.origHealth = that.health;
        var healthBar = new Torch.Sprite(initialCell.Rectangle.x + 5, initialCell.Rectangle.y - 10);
        game.Add(healthBar);
        healthBar.Bind.Texture("health");
        healthBar.drawIndex = 7;
        healthBar.AddUpdate(function(sprite)
        {
            var percent = that.health / that.origHealth;
            if (percent <= 0) percent = 0;
            var width = percent * 50;
            var offset = (64 - width) / 2;
            sprite.Rectangle.width = width;
            sprite.Rectangle.x = that.Rectangle.x + offset;
            sprite.Rectangle.y = that.Rectangle.y - 10;
        });
        that.zTrig = false;

        that.basePower = that.power;
        that.baseStrength = that.strength;

    },

    ImportItem: function(item)
    {
        var that = this;
        switch (item.itemType)
        {
            case ItemType.Passive:
                that.ImportPassive(item);
            break;

            case ItemType.Active:
                that.ImportActive(item);
            break;
        }
    },

    ImportPassive: function(item)
    {
        var that = this;
        if (item.power) that.power += item.power;
        if (item.strength) that.strength += item.strength;
        if (item.health) that.health += item.health;
    },

    ImportActive: function(item)
    {
        var that = this;
        that.ImportPassive(item); //item might also have passive attributes
        item.init(that);
        that.AddUpdate(item.update);
        that.StartUpFunctions.push(item.startTurn);
        that.FinishUpFunctions.push(item.endTurn);
    },

    ExportItem: function(item)
    {

    },

    StartTurn: function()
    {
        var that = this;
        that.PlayerIsInControl = true;
        that.movedThisTurn = false;
        that.doneThisTurn = false;
        that.attackedThisTurn = false;
        that.movesToGo = that.moveRange;
        that.StartUpFunctions.forEach(function(startUp)
        {
            startUp(that);
        });
    },

    _Update: function(sprite)
    {
        VOID;
        var that = sprite;
        //that.HandleKeyBoardMove(); ??not yet
        var player = that.player;
        if (!game.Keys.Z.down && that.zTrig && that.selected)
        {
            that.attackedThisTurn = true;
            that.movedThisTurn = true;
            that.zTrig = false;
            that.selected = false;
            for (var i = 0; i < that.MoveHintCells.length; i++) //try here
            {
                that.MoveHintCells[i].Reveal();
            }
            for (var i = 0; i < that.AttackHintCells.length; i++)
            {
                that.AttackHintCells[i].Reveal();
            }
        }
        if (game.Keys.Z.down && that.selected) that.zTrig = true;

        //that.healthText.x = that.Rectangle.x + 5;
        //that.healthText.y = that.Rectangle.y + 10;

        if (that.attackedThisTurn && that.movedThisTurn && !that.doneThisTurn)
        {
            that.doneThisTurn = true;
            that.FinishUpFunctions.forEach(function(finishUp)
            {
                finishUp(that);
            });
        }

        that.CellsInVison = [];
        for (var i = 0; i < that.grid.Cells.length; i++)
        {
            var cell = that.grid.Cells[i];
            if (that.GetDistance(cell) <= that.vision && !that.CellsAddedToVison[cell.Row + "," + cell.Column])
            {
                that.CellsAddedToVison[cell.Row + "," + cell.Column] = true;
                that.CellsInVison.push(cell);
            }
        }
    }
}

Unit = Class(Unit, "Unit");
Unit.Extend(Torch.Sprite);
Unit.Extend(UnitGrid);
Unit.Extend(UnitGridSearch)
Unit.Extend(UnitEvents);
Unit.Extend(UnitMovement);
Unit.Extend(UnitCombat);
