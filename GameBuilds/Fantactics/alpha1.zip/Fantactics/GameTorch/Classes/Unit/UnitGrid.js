var UnitGrid =
{
    GetDistance: function(cell)
    {
        var that = this;
		var distR = Math.abs(that.locationCell.Row - cell.Row);
		var distC = Math.abs(that.locationCell.Column - cell.Column);
		var dist = distR + distC;
		return dist;
    },
    GetHintCells: function()
    {
        var that = this;
		for (var i = 0; i < that.grid.Cells.length; i++)
		{
			var cell = that.grid.Cells[i];
			var dist = that.GetDistance(cell);
		}
    },
    SetHints: function()
    {
        /*
            Instead of binding a different sprite, should we just add another one?
        */
        var that = this;
        var rawCells = [];
        var rawAttackCells = [];
        that.CellsAddedToVison = [];

        for (var i = 0; i < that.grid.Cells.length; i++)
        {
            var cell = that.grid.Cells[i];
            var dist = that.GetDistance(cell);
            if (dist <= that.movesToGo)
            {
                rawCells.push(cell);
            }
            if (that.movesToGo == 0 && dist <= that.attackRange && dist != 0)
            {
                rawAttackCells.push(cell);
            }
        }

        var prunedCells = that.PruneMoveHints(rawCells);

        //allow to attack a mountain

        for (var i = 0; i < rawCells.length; i++)
        {
            var cell = rawCells[i];
            if (that.GetDistance(cell) <= that.attackRange && that.GetDistance(cell) > 0)
            {
                var shouldPushThisCell = true;

                for (var j = 0; j < prunedCells.length; j++)
                {
                    if (prunedCells[j].Row == cell.Row && prunedCells[j].Column == cell.Column)
                    {
                        shouldPushThisCell = false;
                        break
                    }
                }

                if (shouldPushThisCell) rawAttackCells.push(cell);
            }
        }

        for (var i = 0; i < prunedCells.length; i++)
        {
            var cell = prunedCells[i];
            cell.Bind.Texture("hint_cell");
            that.MoveHintCells.push(cell);
            cell.Click(function(sprite)
            {
                that.MouseMoveToCell(sprite);
            });
        }

        for (var i = 0; i < prunedCells.length; i++)
        {

            var cell1 = prunedCells[i];
            var r = cell1.Row;
            var c = cell1.Column;
            var checks = [];
            for (var k = 1; k <= that.attackRange; k++)
            {
                var MoreChecks = [ that.grid.GetCell(r + k, c), that.grid.GetCell(r - k, c), that.grid.GetCell(r, c + k), that.grid.GetCell(r, c - k) ];
                checks = checks.concat(MoreChecks);
            }

            var dist1 = that.GetDistance(cell1);
            checks.forEach(function(cell)
            {
                if (cell && that.GetDistance(cell) > 1)
                {
                    var dist = that.GetDistance(cell);
                    if (dist > dist1)
                    {
                        var shouldPushCell = true;
                        for (var j = 0; j < prunedCells.length; j++)
                        {
                            var cc = prunedCells[j];
                            if (cc.Row == cell.Row && cc.Column == cell.Column)
                            {
                                shouldPushCell = false;
                                break;
                            }
                        }
                        if (shouldPushCell) rawAttackCells.push(cell);
                    }
                }
            });
            // if (dist <= that.movesToGo && cell.HasUnit && dist > 0 && cell.unit.player.name != that.player.name)
            // {
            // 	rawAttackCells.push(cell);
            // }
            // else if (dist > that.movesToGo && dist <= that.movesToGo + that.attackRange)
            // {
            // 	if (cell.HasUnit && cell.unit.player.name == that.player.name){}
            // 	else {rawAttackCells.push(cell);}
            // }
        }

        var prunedAttackCells = [];

        for (var i = 0; i < rawAttackCells.length; i++)
        {
            var cell = rawAttackCells[i];
            if (cell.Seen[that.playerName])
            {
                prunedAttackCells.push(cell);
            }
        }

        for (var i = 0; i < prunedAttackCells.length; i++)
        {
            var cell = prunedAttackCells[i];
            cell.Bind.Texture("hint_cell_attack");
            that.AttackHintCells.push(cell);
            cell.Click(function(sprite)
            {
                that.AttackUnitInCell(sprite);
            });
        }

        that.MoveHintCells = prunedCells;
    }
}
UnitGrid = Class(UnitGrid);
