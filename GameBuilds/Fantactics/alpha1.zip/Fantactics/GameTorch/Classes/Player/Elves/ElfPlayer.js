(function(){

    var ElfPlayer = new Class(function()
    {
        ;"ElfPlayer";
        this.playerType = "Elf";
        this.placedUnits = [];
        this.SeenCells = [];
        Player.Construct(this);
    });

    ElfPlayer.Inherits(Player);

    window["ElfPlayer"] = ElfPlayer;

})();
