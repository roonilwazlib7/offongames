var Items = {};
var ItemType =
{
    Passive: "PASSIVE",
    Active: "ACTIVE"
};
