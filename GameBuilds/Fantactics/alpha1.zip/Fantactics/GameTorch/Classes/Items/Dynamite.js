Items.Dynamite =
{
    itemType: ItemType.Active,

    damage: 40,

    init: function(sprite)
    {
        sprite.Dynamite = {};
        sprite.Dynamite.fuseIsLit = false;
        sprite.Dynamite.turnsToBlow = 2;
    },

    startTurn: function(sprite)
    {
        sprite.Dynamite.turnsToBlow--;
        if (sprite.Dynamite.turnsToBlow == 0)
        {
            //blow up
            sprite.health -= Items.Dynamite.damage;
        }

    },

    endTurn: function(sprite)
    {

    },

    update: function(sprite)
    {
        if (game.Keys.Q.down && sprite.selected)
        {
            sprite.Dynamite.fuseIsLit = true;
            console.log("dynamite lit!!");
        }
    }
}
