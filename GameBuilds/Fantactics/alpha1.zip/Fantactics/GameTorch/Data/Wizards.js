Data.Wizards =
{
    "Race": "Wizards",
    "Units": {
        "GrandWizard": {
            "name": "GoblinBruiser",
            "health": 50,
            "origHealth": 50,
            "moveRange": 3,
            "attackRange": 1,
            "power": 25,
            "strength": 20,

            "Abilities": [
                "BloodThirsty"
            ],

            "AbilityArgs":{
                "BloodThirsty": {
                    "healthBoost": 10
                }
            }
        },
    }
}
