Data.Goblins =
{
    "Race": "Goblins",
    "Units": {
        "GoblinBruiser": {
            "name": "GoblinBruiser",
            "health": 40,
            "moveRange": 3,
            "attackRange": 1,
            "power": 25,
            "strength": 20,

            "Abilities": [
                "BloodThirsty"
            ],

            "AbilityArgs":{
                "BloodThirsty": {
                    "healthBoost": 10
                }
            }
        },
        "GoblinRusher": {
            "name": "GoblinRusher",
            "health": 10,
            "moveRange": 3,
            "attackRange": 1,
            "power": 30,
            "strength": 10
        }
    }
}
