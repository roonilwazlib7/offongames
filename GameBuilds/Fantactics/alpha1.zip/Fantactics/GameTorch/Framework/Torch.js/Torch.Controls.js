Torch.Controls = {};
Torch.Controls.markers = {};

Torch.Controls.markers.dragActive = false;
Torch.Controls.DragDrop = function(sprite, additionalParameters)
{
    if (!sprite.controls) sprite.controls = {};
    Torch.debuggedItem = sprite;

    sprite.controls.dragging = false;
    sprite.controls.bringToTop = additionalParameters.bringToTop;
    sprite.controls.stayOnTop = additionalParameters.stayOnTop;
    sprite.controls.originalDrawIndex = sprite.drawIndex;
    sprite.controls.dragFinishHasTriggered = false;

    var update = function(sprite)
    {
        if (sprite.controls.dragging)
        {
            var ComputedMouseRec = sprite.fixed ? Object.Clone( sprite.game.Mouse.GetRectangle(sprite.game) ) : sprite.game.Mouse.GetRectangle(sprite.game);

            if (sprite.fixed)
            {
                ComputedMouseRec.x += sprite.game.Viewport.x;
                ComputedMouseRec.y += sprite.game.Viewport.y;
                sprite.Rectangle.x = ComputedMouseRec.x;
                sprite.Rectangle.y = ComputedMouseRec.y;
            }
            // sprite.Rectangle.x = ComputedMouseRec.x - (sprite.Rectangle.width / 2) - (2 * (sprite.game.Viewport.x / 4) );
            // sprite.Rectangle.y = ComputedMouseRec.y - (sprite.Rectangle.height / 2) - (2 * (sprite.game.Viewport.y / 4) );
        }
        if (sprite.mouseOver && sprite.game.Mouse.down && !sprite.controls.dragging && !Torch.Controls.markers.dragActive)
        {
            sprite.controls.dragging = true;
            sprite.controls.dragFinishHasTriggered = false;
            if (sprite.controls.bringToTop) sprite.drawIndex = 100;
            Torch.Controls.markers.dragActive = true;
        }
        else if (!sprite.game.Mouse.down)
        {
            if (!sprite.controls.stayOnTop) sprite.drawIndex = sprite.controls.originalDrawIndex;
            if (additionalParameters.dragFinish && !sprite.controls.dragFinishHasTriggered && sprite.controls.dragging)
            {
                additionalParameters.dragFinish(sprite);
                sprite.controls.dragFinishHasTriggered = true;
            }
            sprite.controls.dragging = false;
            Torch.Controls.markers.dragActive = false;
        }
    }

    sprite.additionalUpdates.push(update);


}


Torch.Controls.WASD = function(sprite, additionalParameters)
{

    if (!sprite.controls) sprite.controls = {};
    var wasd = sprite.controls.wasd = {};
    var params = additionalParameters ? additionalParameters : {};

    wasd.velocity = params.velocity ? params.velocity : 0.1;

    var update = function(sprite)
    {
        var game = sprite.game;

        if (game.Keys.W.down)
        {
            sprite.Rectangle.y -= sprite.controls.wasd.velocity * game.deltaTime;
        }
        if (game.Keys.A.down)
        {
            sprite.Rectangle.x -= sprite.controls.wasd.velocity * game.deltaTime;
        }
        if (game.Keys.S.down)
        {
            sprite.Rectangle.y += sprite.controls.wasd.velocity * game.deltaTime;
        }
        if (game.Keys.D.down)
        {
            sprite.Rectangle.x += sprite.controls.wasd.velocity * game.deltaTime;
        }
    }

    sprite.additionalUpdates.push(update);
}

Torch.Controls.Bind = function(sprite, control, additionalParameters)
{
    switch (control)
    {
        case "DragDrop":
            Torch.Controls.DragDrop(sprite, additionalParameters);
        break;

        case "WASD":
            Torch.Controls.WASD(sprite, additionalParameters);
        break;
    }
}
