var socket = io('http://localhost:8080');

var GameClient = {
    id: new Date().toISOString(),
    clients: [],
    Constructor: function()
    {

    },
    Connect: function(server)
    {
        var that = this;
        server.on("yell", function(data)
        {
            that.clients = data;
        });
    }
};

GameClient.Connect(socket);
