var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');

app.listen(8080);

var clients = [];
var createNewClient = function()
{
  var client = {};
  client.id = Math.random() * 2000;
  return client;
}

function handler (req, res) {
  fs.readFile(__dirname + '/index.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

io.on('connection', function (socket) {
  console.log("starting...");
  var client = createNewClient();
  socket.emit('news', client);
  clients.push(client);
  //console.log(clients);

  socket.on("n", function(data){
    for (var i = 0; i < clients.length; i++)
    {
      if (clients[i].id = data.id)
      {
        clients[i] = data;
      }
    }
    //console.log(clients);
    socket.emit("yell", clients);
  });

});
