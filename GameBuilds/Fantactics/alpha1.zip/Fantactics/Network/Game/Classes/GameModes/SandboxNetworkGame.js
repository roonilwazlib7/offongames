var SandboxNetworkGame =
{
    Constructor: function(grid)
    {

    },
    Update: function()
    {
        var that = this;
        if (game.Keys.A.down)
        {
            //connect as player 1
            SOCKET.emit("connect_player_1", {});
        }
        else if (game.Keys.B.down)
        {
            //connect as player two
            SOCKET.emit("connect_player_2", {});
        }
    }
}
SandboxNetworkGame = Class(SandboxNetworkGame);
