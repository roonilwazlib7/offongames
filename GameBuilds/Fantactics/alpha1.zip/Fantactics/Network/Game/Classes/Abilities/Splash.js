var Splash = function(sprite, effect)
{
    
}
