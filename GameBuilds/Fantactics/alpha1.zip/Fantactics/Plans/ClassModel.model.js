/*
* Model For Class Layouts
*/



(function(){

	var className = new Class(function()
	{
		//constructor code
	});

	//number properties
	className.Prop("p1", 0);
	className.Prop("p2", 1);

	//string properties
	className.Prop("p3", "hello");
	className.Prop("p4", "world");

	//bool properties
	className.Prop("p5", true);
	className.Prop("p6", false);

	//object properties
	className.Prop("p7", null);
	className.Prop("p8", {});

	//function properties
	className.Prop("p9", function()
	{
		//do nothing
	});

	//inherited properties (blending, overriding)

	//number properties
	className.Override("p12", 10);

	//string properties
	className.Override("p13", "hello world");

	//bool properties
	className.Override("p14", false);

	//object properties
	className.Override("p15", {});


	className.Blend("p10", function(){});
	className.Override("p11", function(){});

	//expose class
	window["className"] = className;

})();
