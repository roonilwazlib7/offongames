Pipin.Models = {};
(function(){

    var Model = new Class(function()
    {
        ;"Model";
    });

    var LinearModel = new Class(function()
    {
        ;"LinearModel";
    });

    LinearModel.Inherits(Model);

})();
