(function(){
	var Test = new Class(function()
	{
		;"Test";
	});

	var activeTest = null;
	var grid = new Grid(70);

	var Test1 = {
			testRectangle: new Pipin.Rectangle(50, 50, 100, 100),
			testUnit: null,
			Load: function()
			{
				Test1.testUnit = new Unit(grid);
				Test1.testUnit.Load();
				grid.Load();
			},
			Draw: function()
			{
				if (pipin && pipin.time)
				{
					pipin.canvas.font = "14px monospace";
					pipin.canvas.fillStyle = "red";
					pipin.canvas.fillText("t:" + pipin.time.toString().split(".")[0] + "	dt:" + pipin.deltaTime.toString().split(".")[0] + "		fps:" + (1000 / pipin.deltaTime).toString().split(".")[0] + "", 10, 10);
				}
			},
			Update: function()
			{
				if (pipin.Keys.A.down)
				{
					console.log("key is down!");
				}
				Test1.testUnit.Update();
			}
		};

	var
		Load = function()
		{
			Test1.Load();
		},

		Draw = function()
		{
			Test1.Draw();
		},

		Update = function()
		{
			Test1.Update();
		};

	Test.Properties({
		Load: Load,
		Draw: Draw,
		Update: Update
	});


	window["Test"] = Test;
})();
