(function(){

    var DemonPlayer = new Class(function(grid)
    {
        ;"DemonPlayer";
        this.PlayerType = "DemonPlayer";
    });

    DemonPlayer.Inherits(Player);

    window["DemonPlayer"] = DemonPlayer;

})();
