(function(){

    var HumanPlayer = new Class(function()
    {
        ;"HumanPlayer";
        this.PlayerType = "HumanPlayer";
    });

    HumanPlayer.Inherits(Player);

    window["HumanPlayer"] = HumanPlayer;

})();
