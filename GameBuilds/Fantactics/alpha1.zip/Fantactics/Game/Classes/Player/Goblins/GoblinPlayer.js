(function(){

    var GoblinPlayer = new Class(function()
    {
        ;"GoblinPlayer";
    });

    GoblinPlayer.Inherits(Player);

    window["GoblinPlayer"] = GoblinPlayer;

})();
