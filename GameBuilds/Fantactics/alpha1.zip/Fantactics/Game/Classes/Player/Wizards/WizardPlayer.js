(function(){

    var WizardPlayer = new Class(function()
    {
        ;"WizardPlayer";
        this.PlayerType = "WizardPlayer";
    });

    WizardPlayer.Inherits(Player);

    window["WizardPlayer"] = WizardPlayer;

})();
