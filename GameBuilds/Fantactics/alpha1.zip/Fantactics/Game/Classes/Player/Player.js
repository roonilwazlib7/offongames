
(function(){

	var Player = new Class(function(playerType, grid) //Maybe make a new player within instead?
	{
		;"Player";
		this.PlayerType = playerType; //consider renaming to playerName
		this.grid = grid;
	});
	Player.Prop("HasControl", false);

	Player.Prop("Units", []);
	Player.Prop("HintGridCell", null);
	Player.Prop('SelectedUnit', null);

	Player.Prop("UnitIsSelected", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			if (that.Units[i].selected)
			{
				that.SelectedUnit = that.Units[i];
				return true;
			}
		}
		that.SelectedUnit = null;
		return false;
	});

	Player.Prop("TakeControl", function()
	{
		var that = this;
		that.HasControl = true;
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].PlayerIsInControl = true;
			that.Units[i].movedThisTurn = false;
			that.Units[i].attackedThisTurn = false;
		}
	});

	Player.Prop("GiveUpControl", function()
	{
		var that = this;
		that.HasControl = false;
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].PlayerIsInControl = false;
		}
	});

	Player.Prop("UnitsAreFinishedMoving", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			if (!that.Units[i].movedThisTurn)
			{
				return false;
			}
		}
		return true;
	});

	Player.Prop("UnitsAreFinishedAttacking", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			if (!that.Units[i].attackedThisTurn)
			{
				return false;
			}
		}
		return true;
	});

	Player.Prop("TurnIsDone", function()
	{
		var that = this;
		if (that.UnitsAreFinishedMoving() && that.UnitsAreFinishedAttacking())
		{
			return true;
		}
		return false;
	});

	Player.Prop("Load", function()
	{
		var that = this;
	});

	Player.Prop("Draw", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].Draw();
		}
	});

	Player.Prop("Update", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].Update();
		}
	});

	window["Player"] = Player;

})();
