var SimpleGameModeLoader = new Pipin.Loader([
    ["SimpleGameMode", function(){}],
    ["Unit", Unit.Static.Load],
    //demon units
    ["Cultist", Cultist.Static.Load],
    // ["ExplosiveServant", ExplosiveServant.Static.Load],
    // ["Legion", Legion.Static.Load],
    // ["LordOfDeath", LordOfDeath.Static.Load],
    // ["Zombie", Zombie.Static.Load],
    // ["GrandWizard", GrandWizard.Static.Load],
    //wizard units
    ["Loyalist", Loyalist.Static.Load],
    // ["GrandWizard", GrandWizard.Static.Load],
    // ["WizardAprentice", WizardAprentice.Static.Load],
    // //dwarf units
    // ["DwarvenAxeman", DwarvenAxeman.Static.Load],
    // ["DwarvenCraftsman", DwarvenCraftsman.Static.Load],
    // ["DwarvenKing", DwarvenKing.Static.Load],
    // ["DwarvenTwinLord", DwarvenTwinLord.Static.Load],
    // //elven units
    // ["ElvenArcher", ElvenArcher.Static.Load],
    // ["ElvenHerbalist", ElvenHerbalist.Static.Load],
    // ["ElvenRanger", ElvenRanger.Static.Load],
    // ["ElvenScout", ElvenScout.Static.Load],
    // //goblin units
    // ["GoblinBruiser", GoblinBruiser.Static.Load],
    // ["GoblinRusher", GoblinRusher.Static.Load],
    // ["GoblinTank", GoblinTank.Static.Load],
    // ["GoblinWarLord", GoblinWarLord.Static.Load],
    // //human units
    // ["Alchemist", Alchemist.Static.Load],
    // ["Arbalist", Arbalist.Static.Load],
    // ["Defender", Defender.Static.Load],
    // ["FootMan", FootMan.Static.Load],
    // ["Worker", Worker.Static.Load],
    //Terrain
    ["Mountain", Mountain.Static.Load]

], "0.0.1", "../Game/Framework/Pipin/CSS/logo.png");
