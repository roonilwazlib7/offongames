(function()
{
    var startMap =
    [
        ["Unit", 15, 7]
    ];

    StartMap.Demons.SimpleGameMode = StartMap;
});
