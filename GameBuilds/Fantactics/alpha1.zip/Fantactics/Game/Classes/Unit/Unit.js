

(function(){

	var Unit = new Class(function (grid, texture, initialCell) {
		;"Unit";
		this.grid = grid;
		this.DrawTexture = texture;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;


		this.Load();
	});

	Unit.Inherits(GameObject);
	Unit.Inherits(UnitGrid);
	//numbers
	Unit.Prop("moveRange", 1);
	Unit.Prop("attackRange", 1);
	Unit.Prop("power", 1);
	Unit.Prop("strength", 1);
	Unit.Prop("health", 10);
	//bools
	Unit.Prop("selected", false);
	Unit.Prop("viewed", false);
	Unit.Prop("movedThisTurn", false);
	Unit.Prop("attackedThisTurn", false);
	Unit.Prop("showingHint", true);
	//objects
	Unit.Prop("HintGridCell", null);
	Unit.Prop("AttackHintCellTexture", null);
	Unit.Prop("locationCell", null);
	Unit.Prop("MoveHintCells", []);
	Unit.Prop("AttackHintCells", []);
	Unit.Prop("CellToMovePathMap", []);



	//non-loop functions (these functions aren't called directly in the draw/update loops)


	Unit.Prop("CheckMousePosition", function()
	{
		var that = this;
		if (that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
		{
			return true;
		}
		else
		{
			return false;
		}
	});

	Unit.Prop("CheckMouseDown", function()
	{
		var that = this;
		if (pipin.Mouse.down)
		{
			return true;
		}
		{
			return false;
		}
	});

	Unit.Prop("AdjustViewportWhenUnitIsSelected", function()
	{
		var that = this;
	});

	Unit.Prop("MoveToCell", function(cell)
	{
		var that = this;
	//	that.Rectangle.x = cell.Rectangle.x;
	//	that.Rectangle.y = cell.Rectangle.y;
	//	var movePath = that.CellToMovePathMap[cell.Row.toString() + "," + cell.Column.toString()];
		var moveAnim = new Pipin.Animation.LinearObjectAnimation(that.Rectangle, {y: cell.Rectangle.y, x: cell.Rectangle.x},500);
		moveAnim.Single();

	//	var cameraAnim = new Pipin.Animation.LinearObjectAnimation(pipin.Viewport, {rotation:Math.PI * 2},500,function(viewport){
	//		viewport.rotation = 0;
	//	});
	//	cameraAnim.Single();



		that.movesToGo -= that.GetDistance(cell);

		if (that.movesToGo <= 0)
		{
			that.movedThisTurn = true;

			if (that.attackedThisTurn)
			{
				that.movesToGo = that.moveRange;
			}
		}

		that.locationCell.HasUnit = false;

		that.locationCell = cell;

		that.locationCell.HasUnit = true;

		that.locationCell.unit = that;

	});

	Unit.Prop("AttackUnitInCell", function(cell)
	{
		var that = this;

		var calculatedDamage = that.power - cell.unit.strength;

		cell.unit.health -= calculatedDamage;
		that.attackedThisTurn = true;

		hitAnim = new Pipin.Animation.LinearObjectAnimation(cell.unit.DrawParams, {rotation:2 * Math.PI},500, function(me){
			me.rotation = 0;
		}, false);
		hitAnim.Single();


		if (that.movedThisTurn)
		{
			that.movesToGo = that.moveRange;
		}
	});

	Unit.Prop("CheckDistance", function (cell) {
		var that = this;
		var dist = that.GetDistance(cell);
		if (dist <= that.movesToGo)
		{
			return true;
		}
		else
		{
			return false;
		}
	});

	Unit.Prop("LimitMoveHintCells", function()
	{
		var that = this;

		for (var i = 0; i < that.MoveHintCells.length; i++)
		{
			var Row = that.MoveHintCells[i].Row;
			var Column = that.MoveHintCells[i].Column;
		}
	});

	Unit.Prop("GetDistance", function(cell)
	{
		var that = this;
		var distR = Math.abs(that.locationCell.Row - cell.Row);
		var distC = Math.abs(that.locationCell.Column - cell.Column);
		var dist = distR + distC;
		return dist;
	});

	Unit.Prop("EndTurn", function()
	{
		var that = this;
		that.attackedThisTurn = true;
		that.movedThisTurn = true;
		that.selected = false;
		that.movesToGo = that.moveRange;
	});

	Unit.Prop("GetHintCells", function()
	{
		var that = this;
		for (var i = 0; i < that.grid.Cells.length; i++)
		{
			var cell = that.grid.Cells[i];
			var dist = that.GetDistance(cell);

			var checker = 0;
			if (that.movesToGo <= 5)
			{
				checker = that.movesToGo;
			}
			else
			{
				checker = 5;
			}

			if (dist <= checker && dist != 0 && !cell.HasUnit)
			{
				that.MoveHintCells.push(cell);
			}
			else if (dist <= that.movesToGo && dist != 0 && cell.HasUnit)
			{
				that.AttackHintCells.push(cell);
			}
			else if (dist <= that.movesToGo + that.attackRange && dist != 0)
			{
				//that.AttackHintCells.push(cell);
			}
		}
	});

	//Draw functions
	Unit.Prop("DrawHint", function()
	{
		var that = this;
		if (that.viewed || that.selected)
		{
			pipin.Draw(window.HintTexture, new Pipin.Rectangle(that.Rectangle.x, that.Rectangle.y + that.Rectangle.height, 100, 50), {});
			pipin.canvas.save();
			pipin.canvas.fillStyle = "white";
			pipin.canvas.fillText("Moves: " + that.movesToGo, that.Rectangle.x + pipin.Viewport.x + 5, that.Rectangle.y + pipin.Viewport.y + that.Rectangle.height + 35);
			pipin.canvas.fillText(that.PlayerTitle, that.Rectangle.x + pipin.Viewport.x + 5, that.Rectangle.y + pipin.Viewport.y + that.Rectangle.height + 20);
			pipin.canvas.restore();
		}
	});
	Unit.Prop("HighlightPossibleMoves", function()
	{
		var that = this;

		if (that.selected)
		{
			for (var i = 0; i < that.MoveHintCells.length; i++)
			{
				var cell = that.MoveHintCells[i];
				pipin.Draw(that.HintGridCell, cell.Rectangle, {alpha:0.5});
			}
		}
	});

	Unit.Prop("HighlightPossibleAttacks", function()
	{
		var that = this;

		if (that.selected)
		{
			for (var i = 0; i < that.AttackHintCells.length; i++)
			{
				var cell = that.AttackHintCells[i];
				pipin.Draw(that.AttackHintCellTexture, cell.Rectangle, {alpha:0.5});
			}
		}
	});

	Unit.Prop("DrawInfo", function()
	{
		var that = this;
		pipin.canvas.save();
		pipin.canvas.fillStyle = "white";
		pipin.canvas.fillText(that.health, that.Rectangle.x + pipin.Viewport.x + 50, that.Rectangle.y + pipin.Viewport.y + 10);
		pipin.canvas.fillText(that.power, that.Rectangle.x + pipin.Viewport.x, that.Rectangle.y + pipin.Viewport.y + that.Rectangle.height - 10);
		pipin.canvas.fillText(that.strength, that.Rectangle.x + pipin.Viewport.x + 60, that.Rectangle.y + pipin.Viewport.y + that.Rectangle.height - 10);

		pipin.canvas.fillStyle = that.player.color;
		pipin.canvas.fillRect(pipin.Viewport.x + that.Rectangle.x - 5, pipin.Viewport.y + that.Rectangle.y - 5, 25, 25);

		pipin.canvas.restore();
	});

	//Update functions
	Unit.Prop("CheckIfSelected", function(cellSize)
	{
		var that = this;
		that.cellSize = cellSize;
		if (that.CheckMousePosition() && that.CheckMouseDown() && !that.selected && that.PlayerIsInControl && (!that.movedThisTurn || !that.attackedThisTurn))
		{
			that.selected = true;
			that.DrawParams.alpha = 0.7;
			that.AdjustViewportWhenUnitIsSelected();
			that.MoveHintCells = [];
			that.AttackHintCells = [];
			//get close cells
			//TODO put in own function
			that.GetHintCells();
			that.MoveHintCells = that.PruneMoveHints(that.MoveHintCells);
		}
		else if (that.CheckMousePosition() && that.CheckMouseDown() && !that.viewed && !that.PlayerIsInControl)
		{
			that.viewed = true;
		}
	});

	Unit.Prop("CheckMovement", function(){
		var that = this;
		if (that.selected && pipin.Mouse.down && !that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
		{
			for (var i = 0; i < that.MoveHintCells.length; i++)
			{
				var rect = that.MoveHintCells[i].Rectangle;
				var cell = that.MoveHintCells[i];

				//TODO optimize by only checking hint cells
				if (rect.Intersects(pipin.Mouse.GetRectangle()) && that.CheckDistance(cell) && !cell.HasUnit)
				{
					that.MoveToCell(cell);
				}
			}
		}
		if (that.selected && !pipin.Mouse.down)
		{
			that.DrawParams.alpha = 1;
		}
	});

	Unit.Prop("CheckAttack", function()
	{
		var that = this;
		if (that.selected && pipin.Mouse.down && !that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
		{
			for (var i = 0; i < that.AttackHintCells.length; i++)
			{
				var rect = that.AttackHintCells[i].Rectangle;
				var cell = that.AttackHintCells[i];

				if (rect.Intersects(pipin.Mouse.GetRectangle()) && cell.HasUnit && !that.attackedThisTurn && that.GetDistance(cell) <= that.attackRange)
				{
					that.AttackUnitInCell(cell);
				}
			}
		}
	});

	Unit.Prop("CheckSelected", function()
	{
		var that = this;
		if (pipin.Mouse.down && !that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
		{
			that.selected = false;
		}
	});

	Unit.Prop("CheckViewed", function()
	{
		var that = this;
		if (pipin.Mouse.down && !that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
		{
			that.viewed = false;
		}
	});

	Unit.Prop("CheckKeys", function()
	{
		var that = this;
		if (pipin.Keys.S.down && that.selected)
		{
			that.EndTurn();
		}
	});


	//Loop functions
	Unit.Override("Load", function()
	{
		var that = this;
		Unit.Assets = {};
		Unit.Assets.HintGridCell = pipin.LoadTexture("../Game/Art/HintGridCell.png;1;1");
		Unit.Assets.AttackHintCellTexture = pipin.LoadTexture("../Game/Art/AttackHintCellTexture.png;1;1");
	});

	Unit.Override("Update", function()
	{
		var that = this;
		that.CheckIfSelected();
		that.CheckMovement();
		that.CheckAttack();
		that.CheckKeys();
		that.CheckViewed();
		that.CheckSelected();
		//should be moved to draw
	});

	Unit.Override("Draw", function()
	{
		var that = this;
		pipin.Draw(that.DrawTexture, that.Rectangle, that.DrawParams);
		that.HighlightPossibleMoves();
		that.HighlightPossibleAttacks();
		that.DrawInfo();
		that.DrawHint();
	});

	window["Unit"] = Unit;

})();
