(function(){

    var ElvenRanger = new Class(function(grid, initialCell, player) {
		;"ElvenRanger";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    ElvenRanger.Inherits(Unit);

    ElvenRanger.Override("moveRange", 2);
    ElvenRanger.Override("power", 2);
    ElvenRanger.Override("strength", 1);

    ElvenRanger.Override("Load", function()
    {
        var that = this;
        ElvenRanger.Assets = {};
        ElvenRanger.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ElvenRangerTexture.png");
    });

    window["ElvenRanger"] = ElvenRanger;



})();
