(function(){

    var ElvenHerbalist = new Class(function(grid, initialCell, player) {
		;"ElvenHerbalist";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    ElvenHerbalist.Inherits(Unit);

    ElvenHerbalist.Override("moveRange", 2);
    ElvenHerbalist.Override("power", 2);
    ElvenHerbalist.Override("strength", 1);

    ElvenHerbalist.Override("Load", function()
    {
        var that = this;
        ElvenHerbalist.Assets = {};
        ElvenHerbalist.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ElvenHerbalistTexture.png");
    });

    window["ElvenHerbalist"] = ElvenHerbalist;



})();
