(function(){

    var LordOfDeath = new Class(function(grid, initialCell, player) {
		;"LordOfDeath";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    LordOfDeath.Inherits(Unit);

    LordOfDeath.Override("moveRange", 2);
    LordOfDeath.Override("power", 2);
    LordOfDeath.Override("strength", 1);

    LordOfDeath.Override("Load", function()
    {
        var that = this;
        LordOfDeath.Assets = {};
        LordOfDeath.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/LordOfDeathTexture.png");
    });

    window["LordOfDeath"] = LordOfDeath;



})();
