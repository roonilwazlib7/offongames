(function(){

    var Legion = new Class(function(grid, initialCell, player) {
		;"Legion";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    Legion.Inherits(Unit);

    Legion.Override("moveRange", 2);
    Legion.Override("power", 2);
    Legion.Override("strength", 1);

    Legion.Override("Load", function()
    {
        var that = this;
        Legion.Assets = {};
        Legion.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/LegionTexture.png");
    });

    window["Legion"] = Legion;



})();
