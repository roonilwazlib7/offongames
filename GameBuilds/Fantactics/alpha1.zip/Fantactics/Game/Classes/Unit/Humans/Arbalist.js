(function(){

    var Arbalist = new Class(function(grid, initialCell, player) {
		;"Arbalist";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "Arbalist";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = Arbalist.Assets.DrawTexture;

    });

    Arbalist.Inherits(Unit);

    Arbalist.Override("moveRange", 5);
    Arbalist.Override("power", 2);
    Arbalist.Override("strength", 1);

    Arbalist.Override("Load", function()
    {
        var that = this;
        Arbalist.Assets = {};
        Arbalist.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ArbalistTexture.png");
    });

    window["Arbalist"] = Arbalist;



})();
