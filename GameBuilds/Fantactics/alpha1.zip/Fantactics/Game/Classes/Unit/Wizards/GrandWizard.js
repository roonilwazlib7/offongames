(function(){

    var GrandWizard = new Class(function(grid, initialCell, player) {
		;"GrandWizard";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    GrandWizard.Inherits(Unit);

    GrandWizard.Override("moveRange", 2);
    GrandWizard.Override("power", 2);
    GrandWizard.Override("strength", 1);

    GrandWizard.Override("Load", function()
    {
        var that = this;
        GrandWizard.Assets = {};
        GrandWizard.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/GrandWizardTexture.png");
    });

    window["GrandWizard"] = GrandWizard;



})();
