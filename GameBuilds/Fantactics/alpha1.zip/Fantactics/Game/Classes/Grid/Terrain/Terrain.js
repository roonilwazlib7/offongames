(function(){

    var Terrain = new Class(function()
    {
        ;"Terrain";
    });

    Terrain.Prop("moveSlow", 0);


    window["Terrain"] = Terrain;

})();
