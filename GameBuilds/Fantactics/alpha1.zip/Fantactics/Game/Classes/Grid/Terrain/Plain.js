(function(){

    var Plain = new Class(function()
    {
        ;"Plain";
    });

    Plain.Inherits(Terrain);

    window["Plain"] = Plain;

})();
