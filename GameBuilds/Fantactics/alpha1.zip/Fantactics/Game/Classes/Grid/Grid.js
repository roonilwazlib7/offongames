(function(){

	var Grid = new Class(function(dimension){
		this.cellSize = 70;
		this.dimension = dimension;
	});

	Grid.Prop("cellTexture", null);
	Grid.Prop("activeCellTexture", null);
	Grid.Prop("Cells", []);
	Grid.Prop("CellMap", []);

	Grid.Prop("GetCell", function(row, column)
	{
		var that = this;
		return that.Cells[that.CellMap[row.toString() + ":" + column.toString()]];
	});

	Grid.Prop("Load", function()
	{
		var that = this;
		that.cellTexture = pipin.LoadTexture("../Game/Art/GridCell.png");
		that.activeCellTexture = pipin.LoadTexture("../Game/Art/ActiveGridCell.png");

		var cellsHorizontal = that.dimension;//Math.floor(pipin.Viewport.width / that.cellSize);
		var cellsVertical = that.dimension;//Math.floor(pipin.Viewport.height / that.cellSize);

		for (var i = 0; i <= cellsHorizontal; i++)
		{
			for (var j = 0; j <= cellsHorizontal; j++)
			{
				var rect = new Pipin.Rectangle(i * that.cellSize, j * that.cellSize, that.cellSize, that.cellSize)
				var newCell = new Cell(rect, i, j);
				that.Cells.push(newCell);
				that.CellMap[i.toString() + ":" + j.toString()] = that.Cells.length - 1;
			}
		}
	});
	Grid.Prop("Draw", function()
	{
		var that = this;
		for (var i = 0; i < that.Cells.length; i++)
		{
			var rect = that.Cells[i].Rectangle;
			if (rect.Intersects(pipin.Mouse.GetRectangle()))
			{
				//pipin.Draw(that.activeCellTexture, that.Cells[i].Rectangle, {alpha:0.5});
				//pipin.Draw(that.Cells[i].Terrain.DrawTexture, that.Cells[i].Rectangle, {});
				//that.Cells[i].Terrain.Draw();
			//	pipin.Draw(that.Cells[i].Terrain.DrawTexture, that.Cells[i].Rectangle, {});
				pipin.Draw(that.cellTexture, that.Cells[i].Rectangle, {alpha:0.5});
			}
			else
			{
			//	pipin.Draw(that.cellTexture, that.Cells[i].Rectangle, {alpha:0.5});
			//	pipin.Draw(that.Cells[i].Terrain.DrawTexture, that.Cells[i].Rectangle, {});
			//	pipin.Draw(that.Cells[i].Terrain.DrawTexture, that.Cells[i].Rectangle, {});
				pipin.Draw(that.cellTexture, that.Cells[i].Rectangle, {alpha:0.3});
			}
		}

	});
	Grid.Prop("Update", function(){

	});

	window["Grid"] = Grid;

})();
