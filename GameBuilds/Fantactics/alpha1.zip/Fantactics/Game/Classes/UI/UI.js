(function(){

    var UI = new Class(function(grid)
    {
        this.MouseLimitRight = pipin.Viewport.width - 10;
        this.MouseLimitBottom = pipin.Viewport.height - 10;
        this.grid = grid;

        this.MaxRight = grid.GetCell(grid.dimension - 1,0).Rectangle.x;
        this.MaxLeft = -100;
        this.MaxTop = -100;
        this.MaxBottom = grid.GetCell(0,grid.dimension - 1).Rectangle.y;
        this.BottomUIMenuTexture = pipin.LoadTexture("../Game/Art/UI/BottomUIMenuBackground.png;1;1")
    });

    UI.Prop("MouseLimitRight", 0);
    UI.Prop("MouseLimitLeft", 5);
    UI.Prop("MouseLimitTop", 5);
    UI.Prop("MouseLimitBottom", 0);

    UI.Prop("AdjustViewport", function()
    {
        //TODO fix this crap, mainly up and down
        var that = this;
        var CameraAdjust = 1.0 * pipin.deltaTime;
        if (pipin.Mouse.GetRectangle().x >= that.MouseLimitRight && pipin.Mouse.GetRectangle().x <= that.MaxRight)
        {
            pipin.Viewport.x -= CameraAdjust;
            that.MouseLimitRight += CameraAdjust;
            that.MouseLimitLeft += CameraAdjust;
        }
        if (pipin.Mouse.GetRectangle().x <= that.MouseLimitLeft && pipin.Mouse.GetRectangle().x >= that.MaxLeft)
        {
            pipin.Viewport.x += CameraAdjust;
            that.MouseLimitLeft -= CameraAdjust;
            that.MouseLimitRight -= CameraAdjust;
        }
        if (pipin.Mouse.GetRectangle().y >= that.MouseLimitBottom && pipin.Mouse.GetRectangle().y <= that.MaxBottom)
        {
            pipin.Viewport.y -= CameraAdjust
            that.MouseLimitBottom += CameraAdjust;
            that.MouseLimitTop += CameraAdjust;
        }
        if (pipin.Mouse.GetRectangle().y <= that.MouseLimitTop && pipin.Mouse.GetRectangle().y >= that.MaxTop)
        {
            pipin.Viewport.y += CameraAdjust
            that.MouseLimitBottom -= CameraAdjust;
            that.MouseLimitTop -= CameraAdjust;
        }
    });

    UI.Prop("DrawBottomUIMenu", function()
    {
        var that = this;
        //pipin.Draw(that.BottomUIMenuTexture, new Pipin.Rectangle(0 - pipin.Viewport.x, 600 - pipin.Viewport.y, pipin.Viewport.width, 500), {});
    });

    UI.Prop("Update", function()
    {
        var that = this;
        that.AdjustViewport();
    });

    window["UI"] = UI;

})();
