//enemy (small) file
enemies = [];
enemyIndex = 0;
hits = 0;
function Enemy(rectangle, image, max){
	this.rectangle = rectangle;
	this.image = image;
	this.canvas = canvas;
	this.Update = Update;
	this.counter = 0;
	this.maxHealth = max;
	this.health = max;
	this.hasDamagedPlayer = false;
	this.draw = true;
	this.explodeCounter = 0;
	this.hasExploded = false;
	function Update(){
		Move(this);
		CheckIfHit(this);
		if (IsDead(this)){
			if (hasExploded(this) == false){
				Explode(this);
			}
		}
	}
	function Move(o){
		o.counter++;
		if (o.counter % 3 == 0){
			o.rectangle.y++;
		}
	}
	function CheckIfHit(o){
		for (var i = 0; i < bullets.length; i++){
			if (Intersects(bullets[i].rectangle, o.rectangle)){
				if (bullets[i].draw && o.draw && o.rectangle.y > -10){
					o.health -= DAMAGE;
					bullets[i].draw = false;
					hits++;
				}
			}
		}
	}
	function Explode(o){
		if (o.explodeCounter < 9){
			if (o.explodeCounter < 1){
				PlaySound("sounds/explode.wav");
				player.baseScore += o.maxHealth * 10;
				KILLS++;
			}
			o.image = enemyExplodeTextures[o.explodeCounter];
			o.explodeCounter++;
			
		}
		else {
			o.draw = false;
			o.hasExploded = true;
		}
	}
	function IsDead(o){
	if (o.health <= 0){
		return true;
		}
	else{
		return false;
	}
	}
	function hasExploded(o){
		return o.hasExploded;
	}
	
}