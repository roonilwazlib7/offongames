//powerup file
function HealthEffect(o, player){

	if (o.draw){
		if (Intersects(o.rectangle, player.rectangle)){
			player.health += 2;
			o.draw = false;
			PlaySound("sounds/powerUp.wav");
		}
	}
}
function DamageBoostEffect(o, player){
	if (o.regenerateCounter > 2000){
		DAMAGE = 1;
		_bulletImage = LoadImage("ims/bullet.png");
	}
	if (o.draw){
		if (Intersects(o.rectangle, player.rectangle)){
			DAMAGE += 1;
			o.draw = false;
			_bulletImage = LoadImage("ims/boosted_bullet.png");
			PlaySound("sounds/powerUp.wav");
		}
	}
}
function PowerUp(rectangle, image, effect, player, time){
	this.rectangle = rectangle;
	this.image = image;
	this.draw = false;
	this.originalHieght = rectangle.height;
	this.originalWidth = rectangle.width;
	this.effect = effect;
	this.player = player;
	this.Update = Update;
	this.regenerateCounter = 0;
	this.regenTime = time;
	function Update(){
		effect(this, this.player);
		if (this.draw == false){
			this.regenerateCounter++;
			if (this.regenerateCounter > this.regenTime){
				Generate(this);
				this.regenerateCounter = 0;
			}
		}
	}
	function Generate(o){
		randX = Math.floor((Math.random()*1100)+1);
		randY = Math.floor((Math.random()*500)+1);
		o.rectangle = new Rectangle(randX, randY, o.originalWidth, o.originalHieght);
		o.draw = true;
	}
}