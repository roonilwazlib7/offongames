//Menu
function MenuElement(rectangle, image){
	this.rectangle = rectangle;
	this.image = image;
}
function StoreMenu(c, backgroundImage, rectangle, elements){
	this.rectangle = rectangle;
	this.image = backgroundImage;
	this.WIDTH = c.width;
	this.HEIGHT = c.height;
	this.elements = elements;
	function Update(){
	}
}
function CheckActionOnElements(o){
	for (var i = 0; i < o.elements.length; i++){
	
	}
}
/* function getMousePos(c, evt) {
        var rect = c.getBoundingClientRect();
        return {
          x: evt.clientX - rect.left,
          y: evt.clientY - rect.top
        };
      }
      c.addEventListener('mousemove', function(evt) {
        var mousePos = getMousePos(canvas, evt);
        var message = 'Mouse position: ' + mousePos.x + ',' + mousePos.y;
        writeMessage(canvas, message);
      }, false); */