
function Directions(){
	this.background1 = LoadImage("icon.png");
	this.directions = LoadImage("directions.png");
	this.play = play;
}
function play(im1, im2){
	for (var i = 0; i < 1000; i++){
		Draw_Texture(im1, new Rectangle(0, 0, 1000, 1000));
	}
	for (var j = 0; j < 1000; j++){
		Draw_Texture(im2, new Rectangle(0, 0, 1000, 1000));
	}
}
