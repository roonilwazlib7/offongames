//bullet file
bullets = [];
_bulletCount = 0;
function Bullet(image,rectangle) {
    this.rectangle = rectangle;
    this.image = image;
    this.draw = true;
    this.hit = false;
	this.Update = Update;
	function Update(){
		Move(this);
	}
	function Move(o){
		o.rectangle.y -= 10;
	}
}
function AddBulletPlayer(player){

 document.onkeypress = function (e) { //add a bullet to the game
			var e = window.event || e
			if (e.keyCode == 32) {
				if (player.overHeating == false){
					AddBullet(player);
				}
				PlaySound("sounds/shoot.wav");
			}
		}
	}
 function AddBullet(player) {
        b = new Bullet(_bulletImage,new Rectangle(player.rectangle.x + 25, player.rectangle.y - 50, 50, 100));
        bullets[_bulletCount] = b;
        _bulletCount++;
		player.shots++;
		player.shotsForOverHeat++;
    }